<?php

declare(strict_types=1);

namespace Gemini\Testing\Responses\Fixtures\GenerativeModel;

final class CountTokensResponseFixture
{
    public const ATTRIBUTES = [
        'totalTokens' => 8,
    ];
}
